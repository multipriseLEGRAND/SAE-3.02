import sys
import socket
import random
import threading
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *


# chiffrement rsa avec la cle publique
def rsa_encrypt(msg, key):
    e, n = key
    # on chiffre chaque caractere avec pow(ascii, e, n)
    return " ".join([str(pow(ord(c), e, n)) for c in msg])


# convertir une cle du format string vers tuple
def deserialize_key(k_str):
    try:
        p = k_str.split(',')
        return (int(p[0]), int(p[1]))
    except:
        return None


# recuperer l'adresse ip locale
def get_lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


# worker qui tourne dans un thread pour recevoir les messages
class ClientWorker(QObject):
    msg_received = pyqtSignal(str, str)

    def __init__(self, port):
        super().__init__()
        self.port = port
        self.running = True

    def run(self):
        # creation du serveur tcp
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            server.bind(('0.0.0.0', self.port))
            server.listen(5)

            # boucle d'acceptation des connexions
            while self.running:
                client, addr = server.accept()
                # on lance un thread par connexion
                threading.Thread(target=self.handle, args=(client, addr)).start()
        except Exception as e:
            print(f"Erreur Worker port {self.port}: {e}")

    def handle(self, client, addr):
        # traitement d'une connexion entrante
        try:
            full_data = b""
            while True:
                chunk = client.recv(4096)
                if not chunk:
                    break
                full_data += chunk

            data = full_data.decode('utf-8')

            # si c'est un message relay on le traite
            if data.startswith("RELAY||"):
                content = data.split("||")[1]
                self.msg_received.emit(addr[0], content)
        except:
            pass
        finally:
            client.close()


# fenetre principale du client
class UnifiedClient(QMainWindow):
    def __init__(self):
        super().__init__()

        # demander le pseudo
        self.pseudo, ok = QInputDialog.getText(self, "Identification", "Entrez votre identifiant :")
        if not ok or not self.pseudo:
            sys.exit()

        # listes pour stocker routeurs et clients
        self.nodes = []
        self.clients = []
        self.my_port = 0

        # trouver un port libre
        self.find_and_set_port()

        self.setWindowTitle(f"Client de Messagerie - {self.pseudo}")
        self.setGeometry(100, 100, 500, 650)

        self.init_ui()
        self.start_listening_thread()

        # timer pour actualiser toutes les 5 secondes
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_refresh)
        self.timer.start(5000)

    def find_and_set_port(self):
        # trouver un port disponible entre 6000 et 6050
        self.ip = get_lan_ip()
        start_port = 6000
        found = False

        for p in range(start_port, start_port + 50):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.bind(('0.0.0.0', p))
                s.close()
                self.my_port = p
                found = True
                break
            except OSError:
                continue

        if not found:
            QMessageBox.critical(self, "Erreur", "Aucun port disponible (Plage 6000-6050).")
            sys.exit()

    def start_listening_thread(self):
        # demarrage du thread d'ecoute
        self.lbl_my_ip.setText(f"IP: {self.ip} | Port: {self.my_port}")
        self.worker = ClientWorker(self.my_port)
        self.thread = threading.Thread(target=self.worker.run, daemon=True)
        self.worker.msg_received.connect(self.on_msg_received)
        self.thread.start()

    def init_ui(self):
        # creation de l'interface graphique
        central = QWidget()
        layout = QVBoxLayout()

        # groupe profil utilisateur
        grp = QGroupBox(f"Profil Utilisateur : {self.pseudo}")
        hl = QHBoxLayout()
        self.lbl_my_ip = QLabel("...")
        hl.addWidget(self.lbl_my_ip)
        grp.setLayout(hl)
        layout.addWidget(grp)

        # configuration master
        h_m = QHBoxLayout()
        h_m.addWidget(QLabel("Master IP:"))
        self.txt_mip = QLineEdit("")
        self.txt_mip.setPlaceholderText("Ex: 127.0.0.1")
        h_m.addWidget(self.txt_mip)

        h_m.addWidget(QLabel("Port:"))
        self.txt_mport = QLineEdit("")
        self.txt_mport.setPlaceholderText("5000")
        self.txt_mport.setFixedWidth(60)
        h_m.addWidget(self.txt_mport)
        layout.addLayout(h_m)

        btn_connect = QPushButton("Connexion / Actualiser")
        btn_connect.clicked.connect(lambda: self.register_and_refresh(silent=False))
        layout.addWidget(btn_connect)

        # groupe envoi de message
        grp_send = QGroupBox("Nouveau Message")
        l_send = QVBoxLayout()

        h_dest = QHBoxLayout()
        h_dest.addWidget(QLabel("Destinataire :"))
        self.combo_dest = QComboBox()
        h_dest.addWidget(self.combo_dest)
        l_send.addLayout(h_dest)

        h_hops = QHBoxLayout()
        h_hops.addWidget(QLabel("Nombre de sauts :"))
        self.spin_hops = QSpinBox()
        self.spin_hops.setMinimum(1)
        h_hops.addWidget(self.spin_hops)
        l_send.addLayout(h_hops)

        self.txt_msg = QTextEdit()
        self.txt_msg.setPlaceholderText("Saisissez votre message...")
        self.txt_msg.setMaximumHeight(80)
        l_send.addWidget(self.txt_msg)

        btn_send = QPushButton("Envoyer")
        btn_send.clicked.connect(self.send_onion)
        btn_send.setStyleSheet("background: #dddddd; font-weight: bold;")
        l_send.addWidget(btn_send)

        grp_send.setLayout(l_send)
        layout.addWidget(grp_send)

        # journal de reception
        layout.addWidget(QLabel("<b>Journal de réception :</b>"))
        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setStyleSheet("background: white; color: black; font-family: Courier;")
        layout.addWidget(self.logs)

        central.setLayout(layout)
        self.setCentralWidget(central)

    def auto_refresh(self):
        # actualisation automatique en arriere plan
        self.register_and_refresh(silent=True)

    def register_and_refresh(self, silent=False):
        # enregistrement au master et recuperation des listes
        if not self.txt_mip.text() or not self.txt_mport.text():
            return

        mip = self.txt_mip.text()
        try:
            mport = int(self.txt_mport.text())

            # enregistrement du client
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect((mip, mport))
            msg = f"REGISTER_CLIENT||{self.pseudo}||{self.my_port}"
            s.sendall(msg.encode('utf-8'))
            s.close()

            # recuperation des routeurs
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect((mip, mport))
            s.sendall(b"GET_NODES")
            d_nodes = s.recv(4096).decode('utf-8')
            s.close()

            self.nodes = []
            if d_nodes:
                for n in d_nodes.split(';'):
                    if not n:
                        continue
                    p = n.split(':')
                    self.nodes.append({
                        'ip': p[0],
                        'port': int(p[1]),
                        'key': deserialize_key(p[2])
                    })

            # recuperation des clients
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect((mip, mport))
            s.sendall(b"GET_CLIENTS")
            d_clients = s.recv(4096).decode('utf-8')
            s.close()

            current_selection = self.combo_dest.currentData()
            self.combo_dest.clear()
            self.clients = []

            if d_clients:
                for c in d_clients.split(';'):
                    if not c:
                        continue
                    p = c.split(':')
                    pseudo_c = p[0]
                    if pseudo_c != self.pseudo:
                        self.clients.append({
                            'pseudo': p[0],
                            'ip': p[1],
                            'port': int(p[2])
                        })
                        self.combo_dest.addItem(f"{p[0]} ({p[1]})", p[0])

            # restaurer la selection precedente
            if current_selection:
                idx = self.combo_dest.findData(current_selection)
                if idx != -1:
                    self.combo_dest.setCurrentIndex(idx)

            self.spin_hops.setMaximum(len(self.nodes))
            if not silent:
                self.logs.append(f"[SYSTEME] Mise à jour : {len(self.nodes)} routeurs, {len(self.clients)} clients.")

        except Exception as e:
            if not silent:
                QMessageBox.warning(self, "Erreur Connexion", str(e))
            else:
                print(f"Erreur refresh auto: {e}")

    def send_onion(self):
        # envoi d'un message chiffre en oignon
        idx = self.combo_dest.currentIndex()
        if idx == -1:
            return

        target_pseudo = self.combo_dest.itemData(idx)
        target = next((c for c in self.clients if c['pseudo'] == target_pseudo), None)

        if not target:
            return

        hops = self.spin_hops.value()
        msg = f"[{self.pseudo}] " + self.txt_msg.toPlainText()

        if len(self.nodes) < hops:
            QMessageBox.warning(self, "Erreur", "Nombre de routeurs insuffisant.")
            return

        # selection aleatoire de routeurs
        path = random.sample(self.nodes, hops)

        # construction du payload initial avec ip et port du destinataire
        payload = f"{target['ip']}||{target['port']}||{msg}"

        # construction de l'oignon en chiffrant couche par couche
        for i in range(len(path) - 1, -1, -1):
            node = path[i]
            enc = rsa_encrypt(payload, node['key'])
            if i > 0:
                payload = f"{node['ip']}||{node['port']}||{enc}"
            else:
                final_packet = f"RELAY||{enc}"

        # envoi au premier routeur
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((path[0]['ip'], path[0]['port']))
            s.sendall(final_packet.encode('utf-8'))
            s.close()
            self.logs.append(f"[ENVOI] Message envoyé à {target_pseudo} (Via {hops} noeuds).")
            self.txt_msg.clear()
        except Exception as e:
            self.logs.append(f"[ERREUR] Echec envoi : {e}")

    def on_msg_received(self, ip_source, msg):
        # affichage d'un message recu
        self.logs.append(f"[RECU] De {ip_source} :\n>>> {msg}\n")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = UnifiedClient()
    win.show()
    sys.exit(app.exec())
