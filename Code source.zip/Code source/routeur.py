import sys
import socket
import threading
import random
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *


# calcul du pgcd pour rsa
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


# calcul de l'inverse modulaire pour rsa
def mod_inverse(e, phi):
    d, x1, x2, y1 = 0, 0, 1, 1
    temp_phi = phi
    while e > 0:
        temp1 = temp_phi // e
        temp2 = temp_phi - temp1 * e
        temp_phi, e = e, temp2
        x = x2 - temp1 * x1
        y = d - temp1 * y1
        x2, x1 = x1, x
        d, y1 = y1, y
    if temp_phi == 1:
        return d + phi


# test si un nombre est premier
def is_prime(num):
    if num < 2:
        return False
    if num == 2:
        return True
    if num % 2 == 0:
        return False
    for i in range(3, int(num ** 0.5) + 1, 2):
        if num % i == 0:
            return False
    return True


# generation d'une paire de cles rsa
def generate_keypair():
    # on prend deux nombres premiers entre 100 et 500
    primes = [i for i in range(100, 500) if is_prime(i)]
    p = random.choice(primes)
    q = random.choice(primes)
    while p == q:
        q = random.choice(primes)

    n = p * q
    phi = (p - 1) * (q - 1)

    # trouver e tel que pgcd(e, phi) = 1
    e = random.randrange(1, phi)
    while gcd(e, phi) != 1:
        e = random.randrange(1, phi)

    # calculer d (inverse modulaire)
    d = mod_inverse(e, phi)

    return ((e, n), (d, n))


# dechiffrement rsa avec la cle privee
def rsa_decrypt(ciphertext, private_key):
    try:
        d, n = private_key
        parts = [p for p in ciphertext.split(' ') if p.strip()]
        # on dechiffre chaque nombre avec pow(c, d, n)
        decrypted_chars = [chr(pow(int(char_code), d, n)) for char_code in parts]
        return "".join(decrypted_chars)
    except:
        return None


# convertir une cle en string
def serialize_key(key_tuple):
    return f"{key_tuple[0]},{key_tuple[1]}"


# recuperer l'adresse ip locale
def get_lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


# worker qui tourne dans un thread pour le routeur
class RouterWorker(QObject):
    log_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)

    def __init__(self, master_ip, master_port, my_port):
        super().__init__()
        self.master_ip = master_ip
        self.master_port = int(master_port)
        self.port = int(my_port)
        self.running = True
        self.ip = get_lan_ip()

    def run(self):
        try:
            # creation du serveur tcp
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            try:
                server.bind(('0.0.0.0', self.port))
            except OSError:
                self.error_signal.emit(f"Port {self.port} occupe.")
                return

            # generation des cles rsa
            self.log_signal.emit("[INIT] Generation des cles RSA...")
            self.public_key, self.private_key = generate_keypair()

            # enregistrement au master
            self.register_to_master()

            server.listen(10)
            self.log_signal.emit(f"[ETAT] Routeur en ligne : {self.ip}:{self.port}")

            # boucle d'acceptation des connexions
            while self.running:
                client, addr = server.accept()
                threading.Thread(target=self.handle_packet, args=(client, addr)).start()

        except Exception as e:
            self.error_signal.emit(f"Erreur fatale : {e}")

    def register_to_master(self):
        # envoyer notre port et cle publique au master
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((self.master_ip, self.master_port))
            key_str = serialize_key(self.public_key)
            msg = f"REGISTER_ROUTER||{self.port}||{key_str}"
            s.sendall(msg.encode('utf-8'))
            s.close()
            self.log_signal.emit("[INFO] Enregistrement au Master effectue.")
        except:
            raise Exception("Connexion au Master impossible.")

    def handle_packet(self, client, addr):
        # traitement d'un paquet recu
        try:
            full_data = b""
            while True:
                chunk = client.recv(4096)
                if not chunk:
                    break
                full_data += chunk

            try:
                data = full_data.decode('utf-8')
            except:
                return

            if not data.startswith("RELAY||"):
                return

            try:
                encrypted_part = data.split("||", 1)[1]
            except IndexError:
                return

            self.log_signal.emit(f"[RECU] Paquet de {len(data)} octets. Dechiffrement...")

            # dechiffrement avec notre cle privee
            decrypted = rsa_decrypt(encrypted_part, self.private_key)

            if not decrypted:
                self.log_signal.emit("[ERREUR] Echec dechiffrement RSA.")
                return

            # extraction ip, port et payload suivant
            parts = decrypted.split('||')

            if len(parts) < 3:
                self.log_signal.emit("[ERREUR] Format du message invalide.")
                return

            next_ip = parts[0]
            next_payload = "||".join(parts[2:])

            if next_ip == "FINAL":
                self.log_signal.emit(f"[FINAL] Message livre au destinataire : {next_payload}")
            else:
                try:
                    next_port = int(parts[1])
                    self.log_signal.emit(f"[RELAIS] Transfert vers {next_ip}:{next_port}")
                    self.forward(next_ip, next_port, next_payload)
                except ValueError:
                    self.log_signal.emit(f"[ERREUR] Port invalide : {parts[1]}")

        except Exception as e:
            self.log_signal.emit(f"[EXCEPTION] {e}")
        finally:
            client.close()

    def forward(self, ip, port, payload):
        # relayer le paquet au noeud suivant
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, port))
            s.sendall(f"RELAY||{payload}".encode('utf-8'))
            s.close()
        except:
            self.log_signal.emit(f"[ERREUR] Impossible de contacter le noeud suivant {ip}:{port}")


# fenetre principale du routeur
class RouterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

        # trouver un port libre
        found_port = self.find_free_port(start_port=8001)
        if found_port:
            self.txt_myport.setText(str(found_port))
            self.setWindowTitle(f"Routeur - Port {found_port}")
        else:
            QMessageBox.critical(self, "Erreur", "Aucun port disponible (Plage 8001-8050).")

    def find_free_port(self, start_port):
        # trouver un port disponible entre 8001 et 8050
        for port in range(start_port, start_port + 50):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.bind(('0.0.0.0', port))
                s.close()
                return port
            except OSError:
                continue
        return None

    def init_ui(self):
        # creation de l'interface
        self.setGeometry(200, 200, 450, 550)
        central = QWidget()
        layout = QVBoxLayout()

        # configuration reseau
        grp = QGroupBox("Configuration Réseau")
        fl = QVBoxLayout()

        l1 = QHBoxLayout()
        l1.addWidget(QLabel("IP Master:"))
        self.txt_mip = QLineEdit("")
        self.txt_mip.setPlaceholderText("Ex: 127.0.0.1")
        l1.addWidget(self.txt_mip)

        l1.addWidget(QLabel("Port:"))
        self.txt_mport = QLineEdit("")
        self.txt_mport.setPlaceholderText("5000")
        self.txt_mport.setFixedWidth(60)
        l1.addWidget(self.txt_mport)
        fl.addLayout(l1)

        l2 = QHBoxLayout()
        l2.addWidget(QLabel("Port Local (Auto):"))
        self.txt_myport = QLineEdit("")
        self.txt_myport.setReadOnly(False)
        l2.addWidget(self.txt_myport)
        fl.addLayout(l2)

        grp.setLayout(fl)
        layout.addWidget(grp)

        # bouton demarrage
        self.btn = QPushButton("Démarrer le service")
        self.btn.clicked.connect(self.start)
        self.btn.setStyleSheet("background: #cccccc; color: black; font-weight: bold;")
        layout.addWidget(self.btn)

        # zone de logs
        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setStyleSheet("background: white; color: black; font-family: Courier;")
        layout.addWidget(self.logs)

        central.setLayout(layout)
        self.setCentralWidget(central)

    def log(self, t):
        # afficher un message dans les logs
        self.logs.append(f"{t}")

    def show_error(self, m):
        # afficher une erreur
        QMessageBox.critical(self, "Erreur", m)
        self.btn.setDisabled(False)

    def start(self):
        # demarrage du routeur
        if not self.txt_mip.text() or not self.txt_mport.text():
            QMessageBox.warning(self, "Attention", "Veuillez renseigner l'IP et le Port du Master.")
            return

        self.btn.setDisabled(True)
        self.worker = RouterWorker(self.txt_mip.text(), self.txt_mport.text(), self.txt_myport.text())
        self.thread = threading.Thread(target=self.worker.run, daemon=True)
        self.worker.log_signal.connect(self.log)
        self.worker.error_signal.connect(self.show_error)
        self.thread.start()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = RouterWindow()
    win.show()
    sys.exit(app.exec())
