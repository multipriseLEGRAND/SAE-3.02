import socket
import threading
import sys
import mysql.connector
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *

# Configuration de la base de données
DB_CONFIG = {
    'host': 'localhost',
    'port': 3307,
    'user': 'root',
    'password': 'toto',
    'database': 'onion_project'
}


# Récupérer l'IP locale
def obtenir_ip_locale():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


# Serveur master
class MasterServer(QObject):
    signal_maj = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.ip = "0.0.0.0"
        self.port = 5000
        self.actif = False
        self.nettoyer_base()

    def nettoyer_base(self):
        # Vider les tables au démarrage
        try:
            conn = mysql.connector.connect(**DB_CONFIG)
            cursor = conn.cursor()
            cursor.execute("TRUNCATE TABLE routers")
            cursor.execute("TRUNCATE TABLE clients")
            conn.commit()
            conn.close()
        except:
            pass

    def trouver_port_libre(self):
        # Trouver un port disponible entre 5000 et 5050
        for port in range(5000, 5050):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((self.ip, port))
                sock.listen(10)
                self.serveur = sock
                self.port = port
                self.actif = True
                return True
            except OSError:
                continue
        return False

    def boucle_principale(self):
        # Boucle d'acceptation des connexions
        while self.actif:
            try:
                client, addr = self.serveur.accept()
                threading.Thread(target=self.traiter_client, args=(client, addr)).start()
            except:
                break

    def traiter_client(self, client, addr):
        # Traitement d'une requête
        try:
            donnees = client.recv(8192).decode('utf-8')

            # Enregistrement d'un routeur
            if donnees.startswith("REGISTER_ROUTER||"):
                parts = donnees.split('||')
                self.executer_sql(
                    "REPLACE INTO routers (ip_address, port, public_key) VALUES (%s, %s, %s)",
                    (addr[0], parts[1], parts[2])
                )
                self.signal_maj.emit()

            # Récupération liste routeurs
            elif donnees == "GET_NODES":
                lignes = self.recuperer_sql("SELECT ip_address, port, public_key FROM routers")
                reponse = ";".join([f"{l[0]}:{l[1]}:{l[2]}" for l in lignes])
                client.sendall(reponse.encode('utf-8'))

            # Enregistrement d'un client
            elif donnees.startswith("REGISTER_CLIENT||"):
                parts = donnees.split('||')
                self.executer_sql(
                    "REPLACE INTO clients (pseudo, ip_address, port) VALUES (%s, %s, %s)",
                    (parts[1], addr[0], parts[2])
                )
                self.signal_maj.emit()

            # Récupération liste clients
            elif donnees == "GET_CLIENTS":
                lignes = self.recuperer_sql("SELECT pseudo, ip_address, port FROM clients")
                reponse = ";".join([f"{l[0]}:{l[1]}:{l[2]}" for l in lignes])
                client.sendall(reponse.encode('utf-8'))

        except Exception as e:
            print(f"Erreur: {e}")

        finally:
            client.close()

    def executer_sql(self, sql, params):
        # Exécuter une requête INSERT/UPDATE
        try:
            conn = mysql.connector.connect(**DB_CONFIG)
            cursor = conn.cursor()
            cursor.execute(sql, params)
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erreur SQL: {e}")

    def recuperer_sql(self, sql):
        # Exécuter une requête SELECT
        try:
            conn = mysql.connector.connect(**DB_CONFIG)
            cursor = conn.cursor()
            cursor.execute(sql)
            lignes = cursor.fetchall()
            conn.close()
            return lignes
        except:
            return []


# Fenêtre du master
class FenetreMaster(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Master Server")
        self.setGeometry(100, 100, 600, 400)

        self.server = MasterServer()
        self.server.signal_maj.connect(self.rafraichir)

        # Démarrer le serveur
        if self.server.trouver_port_libre():
            threading.Thread(target=self.server.boucle_principale, daemon=True).start()
            self.construire_ui()
        else:
            sys.exit()

    def construire_ui(self):
        widget = QWidget()
        layout = QVBoxLayout()

        # Affichage du statut
        lbl_statut = QLabel(f"MASTER EN LIGNE - IP: {obtenir_ip_locale()} - PORT: {self.server.port}")
        layout.addWidget(lbl_statut)

        # Tableau routeurs
        layout.addWidget(QLabel("Routeurs:"))
        self.tableau_routeurs = QTableWidget(0, 3)
        self.tableau_routeurs.setHorizontalHeaderLabels(["IP", "Port", "Clé"])
        layout.addWidget(self.tableau_routeurs)

        # Tableau clients
        layout.addWidget(QLabel("Clients:"))
        self.tableau_clients = QTableWidget(0, 3)
        self.tableau_clients.setHorizontalHeaderLabels(["Pseudo", "IP", "Port"])
        layout.addWidget(self.tableau_clients)

        widget.setLayout(layout)
        self.setCentralWidget(widget)

    def rafraichir(self):
        # Mise à jour de l'interface

        # Afficher routeurs
        routeurs = self.server.recuperer_sql("SELECT ip_address, port, public_key FROM routers")
        self.tableau_routeurs.setRowCount(0)
        for i, r in enumerate(routeurs):
            self.tableau_routeurs.insertRow(i)
            self.tableau_routeurs.setItem(i, 0, QTableWidgetItem(r[0]))
            self.tableau_routeurs.setItem(i, 1, QTableWidgetItem(str(r[1])))
            self.tableau_routeurs.setItem(i, 2, QTableWidgetItem("OK"))

        # Afficher clients
        clients = self.server.recuperer_sql("SELECT pseudo, ip_address, port FROM clients")
        self.tableau_clients.setRowCount(0)
        for i, c in enumerate(clients):
            self.tableau_clients.insertRow(i)
            self.tableau_clients.setItem(i, 0, QTableWidgetItem(c[0]))
            self.tableau_clients.setItem(i, 1, QTableWidgetItem(c[1]))
            self.tableau_clients.setItem(i, 2, QTableWidgetItem(str(c[2])))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = FenetreMaster()
    win.show()
    sys.exit(app.exec())